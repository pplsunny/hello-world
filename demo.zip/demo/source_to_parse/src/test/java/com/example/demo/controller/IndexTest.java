package com.example.demo.controller;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;

/**
 * @author Linxingwu
 */
public class IndexTest {
    @Mock
    private Index indexController = new Index();

    @Test
    void testIndex() {
        System.out.println("testcase");
        Assertions.assertEquals("hello world", indexController.index());
    }
}
