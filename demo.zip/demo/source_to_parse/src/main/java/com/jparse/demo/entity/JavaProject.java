package com.example.demo.entity;

import lombok.Data;

import java.io.File;

/**
 * @author Linxingwu
 */
@Data
public class JavaProject {
    String name = "PetClinic";
    String jdk = "17";
    String basePackage = "org.springframework.samples.petclinic";
    File sourceDir = new File("D:\\IdeaProjects\\PetClinic\\src\\main\\java\\org\\springframework\\samples\\petclinic");
    File testDir = new File("D:\\IdeaProjects\\PetClinic\\src\\test\\java\\org\\springframework\\samples\\petclinic");
}
