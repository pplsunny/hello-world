package com.jparse.demo.service;

import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Date;

/**
 * @Description TODO
 * @Author pplsunny
 * @Date 2024/8/4 21:27
 */
@Service
public class GenaiService {
    public String getCurrtenTime() {
        LocalDateTime now = LocalDateTime.now();

        return now.format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"));
    }
}
