package com.example.demo.entity;

import lombok.Data;

/**
 * @author Linxingwu
 */
@Data
public class AITestCase {
    private String packageName;
    private String name;
    private String content;
}
