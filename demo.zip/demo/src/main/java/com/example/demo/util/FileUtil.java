package com.example.demo.util;

import com.example.demo.entity.AITestCase;
import lombok.extern.slf4j.Slf4j;

import java.io.File;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;

/**
 * @author Linxingwu
 */
@Slf4j
public class FileUtil {

    public static void writeTestClass(File directory, String fileName, String content) {
        if (!directory.exists()) {
            directory.mkdirs();
        }
        try {
            Files.write(Path.of(directory.getAbsolutePath(), fileName), content.getBytes(StandardCharsets.UTF_8));
        } catch (IOException e) {
            log.error("cannot write java file {} to {} :{}", fileName, directory, e.getMessage(), e);
        }
    }

    public static void writeTestClass(AITestCase testCase) {
//        writeTestClass(new File(testCase.getDirectory()), testCase.getName(), testCase.getContent());
    }
}
