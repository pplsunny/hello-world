package com.example.demo;

import com.example.demo.entity.AITestCase;
import com.example.demo.entity.JavaProject;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Arrays;


import static com.example.demo.util.FileUtil.writeTestClass;

/**
 * @author Linxingwu
 */
public class Generation {

    public static AITestCase ask(JavaProject project) {
        if (project.getSourceDir().exists()) {

//            Arrays.stream(project.getSourceDir().listFiles()).forEach(file -> {
//                if (file.isDirectory()) {
//                    return askForPackage(file);
//                } else if (file.isFile() && file.getName().endsWith(".java")) {
//                    return askForFile(file);
//                }
//            });

        }
        return null;
    }

    public static void askForFile(File jfile) {

    }

    public static void main(String[] args) {
        askForFile(new File("D:\\IdeaProjects\\PetClinic\\src\\main\\java\\org\\springframework\\samples\\petclinic\\owner\\OwnerController.java"));
    }

    public static void askForPackage(File folder) {
        for (File file : folder.listFiles()) {
            if (file.isDirectory() && file.listFiles().length > 0) {
                askForPackage(file);
            } else if (file.isFile() && file.getName().endsWith(".java")) {
                askForFile(file);
            }

        }
    }
}
