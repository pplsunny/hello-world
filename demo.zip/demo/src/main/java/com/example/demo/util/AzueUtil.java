package com.example.demo.util;


/**
 * @author Linxingwu
 */
public class AzueUtil {


}
